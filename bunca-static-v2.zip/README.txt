BUNCA Specialty Orders — Static Demo v2
======================================

How to run locally
------------------
1) Just open `index.html` in your browser.

How to deploy (pick one)
------------------------
• Vercel: New Project → "Import..." → drag the zip → Framework Preset: "Other" → Deploy.
• Netlify: "Add new site" → "Deploy manually" → upload this zip.
• GitHub Pages: Create a repo → upload `index.html` → Settings → Pages → Deploy from main.
• Cloudflare Pages: Create new project → Direct Upload → upload this zip.

Notes
-----
• Routing uses URL hash (e.g. `#/order`, `#/review`) so **no special rewrites** are needed.
• Admin password (demo): bunca123
• You can customize text/colors by editing `index.html` (look for the Tailwind color variables).